function cloudDB(){
 var subs={ms:[],ev:[],cfg:[]},rev="0",busy=false,timer=null,failed=false;
 function hdr(){return Object.assign({"Content-Type":"application/json"},window.authHdr?authHdr():{})}
 function send(method,body){if(window.CTX&&CTX.ro)return Promise.resolve();return fetch("/api/sync",{method:method,headers:hdr(),body:JSON.stringify(body),keepalive:body.j?body.j.length<60000:true}).then(function(r){if(r.status==401&&window.onAuthFail)onAuthFail();if(!r.ok)throw new Error(r.status)})}
 function poll(){if(busy)return;busy=true;
  fetch("/api/sync?since="+rev,{cache:"no-store",headers:hdr()}).then(function(r){if(r.status==401&&window.onAuthFail)onAuthFail();if(!r.ok)throw new Error(r.status);return r.json()}).then(function(d){
   failed=false;var by={ms:[],ev:[],cfg:[]};
   d.changes.forEach(function(c){if(by[c.col])by[c.col].push({type:c.deleted?"removed":"modified",doc:{id:c.id,data:function(){return{j:c.j}}}});rev=c.rev});
   ["ms","ev","cfg"].forEach(function(col){var ch=by[col];subs[col].forEach(function(s){if(s.first||ch.length){s.first=false;s.cb({docChanges:function(){return ch}})}})});
   if(d.changes.length>=2000)setTimeout(poll,0);
  }).catch(function(){failed=true;["ms","ev","cfg"].forEach(function(col){subs[col].forEach(function(s){s.err&&s.err()})})}).finally(function(){busy=false})}
 function start(){clearInterval(timer);timer=setInterval(function(){if(document.visibilityState!=="hidden")poll()},3000)}
 document.addEventListener("visibilitychange",function(){if(document.visibilityState==="visible")poll()});
 window.addEventListener("online",poll);
 return{collection:function(col){return{
  doc:function(id){return{set:function(v){return send("PUT",{col:col,id:id,j:v.j})},delete:function(){return send("DELETE",{col:col,id:id})}}},
  onSnapshot:function(cb,err){subs[col].push({cb:cb,err:err,first:true});clearTimeout(cloudDB.k);cloudDB.k=setTimeout(function(){poll();start()},0)}}}}}
if(navigator.storage&&navigator.storage.persist){navigator.storage.persist().catch(function(){})}
if("serviceWorker" in navigator&&location.protocol.indexOf("http")==0){window.addEventListener("load",function(){navigator.serviceWorker.register("/sw.js",{updateViaCache:"none"}).catch(function(){})})}
(function(){
  if(location.protocol.indexOf("http")!=0)return;
  var current=null;
  function check(){
    fetch("/version.json?t="+Date.now(),{cache:"no-store"}).then(function(r){return r.ok?r.json():null}).then(function(v){
      if(!v||!v.version)return;
      if(current===null){current=v.version;return}
      if(v.version!==current){current=v.version;if(document.visibilityState==="hidden"){location.reload()}else{showUpdate()}}
    }).catch(function(){});
  }
  function showUpdate(){
    if(document.getElementById("upd-bar"))return;
    var b=document.createElement("button");
    b.id="upd-bar";b.type="button";
    b.textContent="新しいバージョンがあります。タップで更新（データは保持されます）";
    b.style.cssText="position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:99999;padding:12px 18px;border:0;border-radius:999px;background:#111;color:#fff;font-size:14px;box-shadow:0 4px 16px rgba(0,0,0,.3);max-width:92vw";
    b.onclick=function(){location.reload()};
    document.body.appendChild(b);
  }
  check();
  setInterval(check,60000);
  document.addEventListener("visibilitychange",function(){if(document.visibilityState==="visible")check()});
})();
