import { NextResponse } from "next/server"
import { ensureSchema, getSession } from "@/lib/auth"

// 組み合わせ表・進行表の写真を AI(Claude) で読み取る API。
// Vercel の環境変数に ANTHROPIC_API_KEY を設定してください（任意: ANTHROPIC_MODEL）。
// APIキーの不正利用を防ぐため、ログイン済み（チームコードまたは管理者）のみ利用できます。
export const maxDuration = 60
export const dynamic = "force-dynamic"

const PROMPT = "この画像は日本のソフトテニスの大会資料（組み合わせ表・トーナメント表・リーグ表・進行表のいずれか）です。内容を読み取り、次のJSONだけを返してください（説明文やコードフェンスは不要）。\n{\"kind\":\"bracket または schedule\",\"matches\":[{\"n\":試合番号(整数・不明ならnull),\"r\":\"回戦等(例: 1回戦/2回戦/準々決勝/準決勝/決勝/予選リーグ/決勝T/3位T)\",\"a\":\"上側(または左側)のチーム名またはペア名\",\"b\":\"下側(または右側)のチーム名またはペア名\",\"pa\":[\"後衛名\",\"前衛名\"]またはnull,\"pb\":[\"後衛名\",\"前衛名\"]またはnull,\"w\":\"a または b または空文字\",\"sc\":\"スコアが書かれていれば4-2のように、なければ空文字\"}],\"schedule\":[{\"c\":コート番号(整数),\"o\":そのコートでの試合順(1から),\"n\":試合番号}]}\nルール:\n- トーナメント表・リーグ表なら kind を bracket とし matches を埋め、schedule は空配列にする。\n- 進行表（コート別の試合順や時間割）なら kind を schedule とし schedule を埋める。試合番号は組み合わせ表の番号（丸数字・数字）と同じものを使う。matches は空配列にする。\n- 試合番号は表に書かれた番号を優先する。番号が無い場合は上から順に1,2,3…と付ける。\n- 赤い線・赤丸・赤ペンで勝ち上がり（勝者）が示されている場合は、その勝者側を w に入れる。印が無い試合は w を空文字にする。\n- 上位ラウンドの a と b には、表に書かれているチーム名を入れる（赤線で勝ち上がったチーム名が記入されていればそれを使う）。未確定なら空文字にする。\n- 読み取れない文字は推測せず、空文字またはnullにする。チーム名は表記どおり（学校名のみ、学校名にA・Bが付く場合など）。"

// 進行表を「表の形のまま」読み取るためのプロンプト
const GRID_PROMPT = "この画像は日本のソフトテニスの大会の進行表（コート別・時間帯別などの試合予定表）です。表の構造をそのまま再現できるよう、次のJSONだけを返してください（説明文やコードフェンスは不要）。\n{\"title\":\"表のタイトル(無ければ空文字)\",\"corner\":\"左上の見出しセル(無ければ空文字)\",\"cols\":[\"列見出し1\",\"列見出し2\"],\"rows\":[{\"label\":\"行見出し(時間・試合順など。無ければ空文字)\",\"cells\":[{\"t\":\"セルの文字\",\"s\":1}]}],\"notes\":\"表の外の注意書き(無ければ空文字)\"}\nルール:\n- 見た目の表をそのまま再現する。列の順・行の順を変えない。行見出し列は label に入れ、cells には含めない。左上の見出しは corner に入れる。\n- cols は行見出し列を除いたデータ列の見出し（コート名など）。見出しが無ければ「1」「2」…のように列番号を入れる。\n- cells は左から順に、その行の全セルを並べる。セルが複数列にまたがる（結合されている）場合は s にまたがる列数を入れる（通常は1）。各行の s の合計は cols の数と同じにする。\n- 空欄のセルも省略せず {\"t\":\"\",\"s\":1} として入れる。\n- セルの中に複数行ある場合は \\n でつなぐ。1つの試合は「学校名 または 学校名A\\n学校名B」「A高校 vs B高校」のように、表記どおりに書く。試合番号（丸数字・数字）や回戦も表記どおりに残す。\n- 赤線・赤丸・手書きの結果などは無視し、印刷された文字だけを読み取る。読み取れない文字は推測せず空文字にする。"

export async function POST(req: Request) {
  const key = process.env.ANTHROPIC_API_KEY
  if (!key) {
    return NextResponse.json(
      { error: "AI読み取りが未設定です。Vercelの環境変数 ANTHROPIC_API_KEY を設定してください。" },
      { status: 501 },
    )
  }
  await ensureSchema()
  const s = await getSession(req)
  if (!s || !s.tid || (s.k !== "t" && s.k !== "a")) {
    return NextResponse.json({ error: "ログインが必要です" }, { status: 401 })
  }
  let image = ""
  let mode = ""
  try {
    const b = await req.json()
    image = String(b?.image || "")
    mode = String(b?.mode || "")
  } catch {
    return NextResponse.json({ error: "invalid request" }, { status: 400 })
  }
  const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(image)
  if (!m || image.length > 6_000_000) {
    return NextResponse.json({ error: "画像が不正、または大きすぎます" }, { status: 400 })
  }
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: mode === "grid" ? 8000 : 6000,
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: m[1], data: m[2] } },
            { type: "text", text: mode === "grid" ? GRID_PROMPT : PROMPT },
          ],
        },
      ],
    }),
  })
  const j: any = await r.json().catch(() => ({}))
  if (!r.ok) {
    return NextResponse.json({ error: j?.error?.message || "AIの呼び出しに失敗しました" }, { status: 502 })
  }
  const text = (j.content || []).map((c: any) => (c.type === "text" ? c.text : "")).join("")
  return NextResponse.json({ text })
}
