import { pool } from "@/lib/db"
import { ensureSchema, getSession, noStore } from "@/lib/auth"

export const dynamic = "force-dynamic"

const COLLECTIONS = new Set(["ms", "ev", "cfg"])
const MAX_DOC_BYTES = 2_000_000

function validKey(col: unknown, id: unknown): col is string {
  return (
    typeof col === "string" &&
    COLLECTIONS.has(col) &&
    typeof id === "string" &&
    id.length > 0 &&
    id.length <= 100
  )
}

/* チームのデータは st_docs の col を「<チームID>~<コレクション>」に名前空間化して保存する。
   そのため別チームのデータは物理的に同じクエリでは読めない。 */
export async function GET(req: Request) {
  await ensureSchema()
  const s = await getSession(req)
  if (!s || !s.tid) return Response.json({ error: "unauthorized" }, { status: 401, headers: noStore })
  const sinceParam = new URL(req.url).searchParams.get("since") ?? "0"
  const since = /^\d{1,18}$/.test(sinceParam) ? sinceParam : "0"
  const prefix = s.tid + "~"
  const { rows } = await pool.query(
    "SELECT col, id, j, deleted, rev::text AS rev FROM st_docs WHERE col LIKE $2 AND rev > $1 ORDER BY rev ASC LIMIT 2000",
    [since, prefix + "%"],
  )
  const changes = rows.map((r: any) => ({ ...r, col: String(r.col).slice(prefix.length) }))
  return Response.json({ changes }, { headers: noStore })
}

async function writer(req: Request) {
  await ensureSchema()
  const s = await getSession(req)
  if (!s || !s.tid) return { err: Response.json({ error: "unauthorized" }, { status: 401, headers: noStore }) }
  if (s.k !== "t" && s.k !== "a") {
    return { err: Response.json({ error: "閲覧専用です" }, { status: 403, headers: noStore }) }
  }
  return { tid: s.tid }
}

export async function PUT(req: Request) {
  const w = await writer(req)
  if (w.err) return w.err
  const body = await req.json().catch(() => null)
  if (!body || !validKey(body.col, body.id) || typeof body.j !== "string") {
    return Response.json({ error: "invalid" }, { status: 400 })
  }
  if (body.j.length > MAX_DOC_BYTES) {
    return Response.json({ error: "too large" }, { status: 413 })
  }
  try {
    JSON.parse(body.j)
  } catch {
    return Response.json({ error: "invalid json" }, { status: 400 })
  }
  await pool.query(
    `INSERT INTO st_docs (col, id, j, deleted) VALUES ($1, $2, $3, false)
     ON CONFLICT (col, id) DO UPDATE SET j = EXCLUDED.j, deleted = false, rev = nextval('st_rev'), updated_at = now()
     WHERE st_docs.j IS DISTINCT FROM EXCLUDED.j OR st_docs.deleted`,
    [w.tid + "~" + body.col, body.id, body.j],
  )
  return Response.json({ ok: true }, { headers: noStore })
}

export async function DELETE(req: Request) {
  const w = await writer(req)
  if (w.err) return w.err
  const body = await req.json().catch(() => null)
  if (!body || !validKey(body.col, body.id)) {
    return Response.json({ error: "invalid" }, { status: 400 })
  }
  await pool.query(
    `UPDATE st_docs SET j = NULL, deleted = true, rev = nextval('st_rev'), updated_at = now()
     WHERE col = $1 AND id = $2 AND NOT deleted`,
    [w.tid + "~" + body.col, body.id],
  )
  return Response.json({ ok: true }, { headers: noStore })
}
