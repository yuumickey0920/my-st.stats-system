import crypto from "node:crypto"
import { pool } from "@/lib/db"
import { ensureSchema, getSession, noStore } from "@/lib/auth"

export const dynamic = "force-dynamic"

const bad = (m: string, status = 400) => Response.json({ error: m }, { status, headers: noStore })
const TOKEN = /^[A-Za-z0-9_-]{16,64}$/

async function load(token: string) {
  if (!TOKEN.test(token)) return null
  const sh = (await pool.query("SELECT tid, mid FROM st_shares WHERE token = $1 AND NOT revoked", [token])).rows[0]
  if (!sh) return null
  const d = (await pool.query("SELECT j FROM st_docs WHERE col = $1 AND id = $2 AND NOT deleted", [sh.tid + "~ms", sh.mid])).rows[0]
  if (!d || !d.j) return null
  let m: any
  try {
    m = JSON.parse(d.j)
  } catch {
    return null
  }
  return { tid: sh.tid as string, mid: sh.mid as string, m }
}

/** 共有リンクを開いた人（チームコード不要）が試合と振り返りを見る */
export async function GET(req: Request) {
  await ensureSchema()
  const token = new URL(req.url).searchParams.get("s") || ""
  const x = await load(token)
  if (!x) return bad("共有リンクが無効です（停止されたか、データが削除されました）", 404)
  const team = (await pool.query("SELECT name FROM st_teams WHERE id = $1", [x.tid])).rows[0]
  let ev: any = null
  if (x.m.ev) {
    const e = (await pool.query("SELECT j FROM st_docs WHERE col = $1 AND id = $2 AND NOT deleted", [x.tid + "~ev", x.m.ev])).rows[0]
    try {
      if (e && e.j) {
        const o = JSON.parse(e.j)
        ev = { id: o.id, name: o.name, date: o.date }
      }
    } catch {}
  }
  return Response.json({ team: team ? team.name : "", match: x.m, event: ev }, { headers: noStore })
}

const s_ = (v: unknown, n: number) => String(v ?? "").slice(0, n)

/** 受け取った人が入力できるのは「振り返り・コンディション」関連の項目だけ */
function sanitize(p: any): Record<string, unknown> {
  const o: Record<string, unknown> = {}
  if (Array.isArray(p?.rv)) o.rv = [0, 1, 2].map((i) => s_(p.rv[i], 4000))
  if (Array.isArray(p?.cd)) {
    o.cd = [0, 1].map((i) => {
      const c = p.cd[i] || {}
      return {
        rt: Array.isArray(c.rt) ? c.rt.slice(0, 20).map((z: unknown) => s_(z, 30)) : [],
        rtx: s_(c.rtx, 1000),
        mu: s_(c.mu, 1000),
        bf: s_(c.bf, 2000),
        dn: s_(c.dn, 2000),
        bed: s_(c.bed, 5),
        wk: s_(c.wk, 5),
      }
    })
  }
  if (p?.tp && typeof p.tp === "object" && JSON.stringify(p.tp).length < 20000) o.tp = p.tp
  if (p?.rvl && typeof p.rvl === "object") o.rvl = { by: s_(p.rvl.by, 40), t: Number(p.rvl.t) || Date.now() }
  return o
}

export async function PUT(req: Request) {
  await ensureSchema()
  const token = new URL(req.url).searchParams.get("s") || ""
  const x = await load(token)
  if (!x) return bad("共有リンクが無効です", 404)
  const b = await req.json().catch(() => null)
  if (!b || typeof b.patch !== "object") return bad("invalid")
  const m = Object.assign(x.m, sanitize(b.patch))
  await pool.query(
    "UPDATE st_docs SET j = $3, rev = nextval('st_rev'), updated_at = now() WHERE col = $1 AND id = $2 AND NOT deleted",
    [x.tid + "~ms", x.mid, JSON.stringify(m)],
  )
  return Response.json({ ok: true }, { headers: noStore })
}

/** チーム側（ログイン済み）が共有リンクを発行／停止する */
export async function POST(req: Request) {
  await ensureSchema()
  const s = await getSession(req)
  if (!s || !s.tid || (s.k !== "t" && s.k !== "a")) return bad("unauthorized", 401)
  const b = await req.json().catch(() => null)
  const mid = String(b?.mid || "")
  if (!/^m\d{1,20}$/.test(mid)) return bad("invalid")
  if (!(await pool.query("SELECT 1 FROM st_docs WHERE col = $1 AND id = $2 AND NOT deleted", [s.tid + "~ms", mid])).rowCount) {
    return bad("試合データがまだ同期されていません。少し待ってからもう一度お試しください", 409)
  }
  const token = crypto.randomBytes(18).toString("base64url")
  const r = await pool.query(
    `INSERT INTO st_shares (token, tid, mid) VALUES ($1, $2, $3)
     ON CONFLICT (tid, mid) DO UPDATE SET
       token = CASE WHEN st_shares.revoked THEN EXCLUDED.token ELSE st_shares.token END, revoked = false
     RETURNING token`,
    [token, s.tid, mid],
  )
  return Response.json({ token: r.rows[0].token }, { headers: noStore })
}

export async function DELETE(req: Request) {
  await ensureSchema()
  const s = await getSession(req)
  if (!s || !s.tid || (s.k !== "t" && s.k !== "a")) return bad("unauthorized", 401)
  const b = await req.json().catch(() => null)
  await pool.query("UPDATE st_shares SET revoked = true WHERE tid = $1 AND mid = $2", [s.tid, String(b?.mid || "")])
  return Response.json({ ok: true }, { headers: noStore })
}
