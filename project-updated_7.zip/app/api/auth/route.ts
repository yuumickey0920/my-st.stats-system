import { pool } from "@/lib/db"
import { addFail, adminCode, clearFail, clientIp, ensureSchema, isLimited, mint, noStore, normCode, same } from "@/lib/auth"

export const dynamic = "force-dynamic"

/** チームコード（または管理者コード）でログインしてトークンを受け取る */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  const raw = String(body?.code ?? "").normalize("NFKC").trim()
  if (!raw || raw.length > 64) return Response.json({ error: "コードを入力してください" }, { status: 400, headers: noStore })
  const ip = clientIp(req)
  if (isLimited(ip)) {
    return Response.json({ error: "試行回数が多すぎます。10分ほど待ってからお試しください" }, { status: 429, headers: noStore })
  }
  await ensureSchema()
  const ac = adminCode()
  if (ac && same(raw, ac)) {
    clearFail(ip)
    return Response.json({ role: "admin", token: mint("A") }, { headers: noStore })
  }
  const r = await pool.query("SELECT id, name, code FROM st_teams WHERE code = $1", [normCode(raw)])
  const t = r.rows[0]
  if (!t) {
    addFail(ip)
    return Response.json({ error: "チームコードが正しくありません" }, { status: 401, headers: noStore })
  }
  clearFail(ip)
  const view = body?.view === true
  return Response.json(
    { role: view ? "view" : "team", token: mint(view ? "v" : "t", t.id, t.code), team: { id: t.id, name: t.name } },
    { headers: noStore },
  )
}
