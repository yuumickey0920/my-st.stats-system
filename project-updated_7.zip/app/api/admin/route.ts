import crypto from "node:crypto"
import { pool } from "@/lib/db"
import { adminCode, ensureSchema, getSession, mint, noStore, normCode } from "@/lib/auth"

export const dynamic = "force-dynamic"

const bad = (m: string, status = 400) => Response.json({ error: m }, { status, headers: noStore })

function genCode(): string {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // 紛らわしい文字(I,O,0,1)を除外
  let s = ""
  const b = crypto.randomBytes(6)
  for (let i = 0; i < 6; i++) s += A[b[i] % A.length]
  return s
}
function cleanName(v: unknown): string {
  return String(v ?? "").normalize("NFKC").trim().slice(0, 40)
}
function cleanCode(v: unknown): string | null {
  const c = normCode(v)
  return /^[A-Z0-9_-]{3,32}$/.test(c) ? c : null
}

/** 総管理者専用API。すべて ADMIN_CODE で取得した管理者トークンが必要 */
export async function POST(req: Request) {
  await ensureSchema()
  const s = await getSession(req)
  if (!s || s.k !== "A") return bad("管理者のみ利用できます", 401)
  const b = await req.json().catch(() => null)
  const act = String(b?.act || "")

  if (act === "list") {
    const teams = (await pool.query("SELECT id, name, code, created_at FROM st_teams ORDER BY created_at")).rows
    const st = (
      await pool.query(
        `SELECT split_part(col,'~',1) AS tid, split_part(col,'~',2) AS c,
                count(*) FILTER (WHERE NOT deleted)::int AS n, max(updated_at) AS u
           FROM st_docs WHERE col LIKE '%~%' GROUP BY 1,2`,
      )
    ).rows
    const sh = (await pool.query("SELECT tid, count(*)::int AS n FROM st_shares WHERE NOT revoked GROUP BY tid")).rows
    const legacy = (
      await pool.query(
        "SELECT col, count(*) FILTER (WHERE NOT deleted)::int AS n FROM st_docs WHERE col IN ('ms','ev','cfg') GROUP BY col",
      )
    ).rows
    const out = teams.map((t: any) => {
      const mine = st.filter((x: any) => x.tid === t.id)
      const g = (c: string) => (mine.find((x: any) => x.c === c) || {}).n || 0
      const u = mine.reduce((a: any, x: any) => (!a || (x.u && x.u > a) ? x.u : a), null)
      return {
        id: t.id,
        name: t.name,
        code: t.code,
        created: t.created_at,
        matches: g("ms"),
        events: g("ev"),
        updated: u,
        shares: (sh.find((x: any) => x.tid === t.id) || {}).n || 0,
      }
    })
    const lg: Record<string, number> = {}
    legacy.forEach((x: any) => (lg[x.col] = x.n))
    return Response.json({ teams: out, legacy: lg, adminConfigured: true }, { headers: noStore })
  }

  if (act === "create") {
    const name = cleanName(b.name)
    if (!name) return bad("チーム名を入力してください")
    let code = b.code ? cleanCode(b.code) : genCode()
    if (!code) return bad("コードは英数字・-・_ の3〜32文字で入力してください")
    if (code === normCode(adminCode())) return bad("そのコードは使えません")
    if ((await pool.query("SELECT 1 FROM st_teams WHERE code = $1", [code])).rowCount) {
      if (b.code) return bad("そのコードは他のチームで使われています")
      code = genCode()
    }
    const id = crypto.randomBytes(5).toString("hex")
    await pool.query("INSERT INTO st_teams (id, name, code) VALUES ($1, $2, $3)", [id, name, code])
    return Response.json({ ok: true, id, code }, { headers: noStore })
  }

  if (act === "update") {
    const id = String(b.id || "")
    const t = (await pool.query("SELECT id FROM st_teams WHERE id = $1", [id])).rows[0]
    if (!t) return bad("チームが見つかりません", 404)
    if (b.name !== undefined) {
      const name = cleanName(b.name)
      if (!name) return bad("チーム名を入力してください")
      await pool.query("UPDATE st_teams SET name = $2 WHERE id = $1", [id, name])
    }
    if (b.code !== undefined) {
      const code = b.code === "" ? genCode() : cleanCode(b.code)
      if (!code) return bad("コードは英数字・-・_ の3〜32文字で入力してください")
      if (code === normCode(adminCode())) return bad("そのコードは使えません")
      if ((await pool.query("SELECT 1 FROM st_teams WHERE code = $1 AND id <> $2", [code, id])).rowCount) {
        return bad("そのコードは他のチームで使われています")
      }
      await pool.query("UPDATE st_teams SET code = $2 WHERE id = $1", [id, code])
    }
    return Response.json({ ok: true }, { headers: noStore })
  }

  if (act === "delete") {
    const id = String(b.id || "")
    const t = (await pool.query("SELECT id, name FROM st_teams WHERE id = $1", [id])).rows[0]
    if (!t) return bad("チームが見つかりません", 404)
    if (cleanName(b.confirm) !== t.name) return bad("確認のチーム名が一致しません")
    await pool.query("DELETE FROM st_docs WHERE col LIKE $1", [id + "~%"])
    await pool.query("DELETE FROM st_shares WHERE tid = $1", [id])
    await pool.query("DELETE FROM st_teams WHERE id = $1", [id])
    return Response.json({ ok: true }, { headers: noStore })
  }

  if (act === "enter") {
    const t = (await pool.query("SELECT id, name FROM st_teams WHERE id = $1", [String(b.id || "")])).rows[0]
    if (!t) return bad("チームが見つかりません", 404)
    return Response.json({ token: mint("a", t.id), team: { id: t.id, name: t.name } }, { headers: noStore })
  }

  if (act === "migrate") {
    const id = String(b.id || "")
    if (!(await pool.query("SELECT 1 FROM st_teams WHERE id = $1", [id])).rowCount) return bad("チームが見つかりません", 404)
    const r = await pool.query(
      `UPDATE st_docs SET col = $1 || '~' || col, rev = nextval('st_rev'), updated_at = now()
        WHERE col IN ('ms','ev','cfg')
          AND NOT EXISTS (SELECT 1 FROM st_docs d2 WHERE d2.col = $1 || '~' || st_docs.col AND d2.id = st_docs.id)`,
      [id],
    )
    return Response.json({ ok: true, moved: r.rowCount }, { headers: noStore })
  }

  return bad("unknown action")
}
