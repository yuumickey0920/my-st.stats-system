export const dynamic = "force-dynamic"

const bootVersion = String(Date.now())

export function GET() {
  const version = process.env.VERCEL_DEPLOYMENT_ID || process.env.VERCEL_GIT_COMMIT_SHA || bootVersion
  return Response.json({ version }, { headers: { "Cache-Control": "no-store" } })
}
