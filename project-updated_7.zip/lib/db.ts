import { Pool } from "pg"

const globalForPool = globalThis as unknown as { stPool?: Pool }

export const pool =
  globalForPool.stPool ?? new Pool({ connectionString: process.env.DATABASE_URL, max: 5 })

if (process.env.NODE_ENV !== "production") globalForPool.stPool = pool
