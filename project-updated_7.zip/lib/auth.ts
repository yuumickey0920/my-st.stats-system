import crypto from "node:crypto"
import { pool } from "@/lib/db"

/**
 * 認証まわり（チームコード / 管理者コード / 署名付きトークン）
 *  - 環境変数 ADMIN_CODE   : 総管理者のコード（必須。未設定だと管理者ログインは無効）
 *  - 環境変数 SESSION_SECRET: トークン署名用の秘密鍵（任意。未設定なら ADMIN_CODE 等から生成）
 * トークン種別  t=チーム(編集可) / v=他チーム閲覧(読み取り専用) / a=管理者がチームを編集 / A=管理者本人
 */
export type Kind = "t" | "v" | "a" | "A"
export type Session = { k: Kind; tid?: string; team?: { id: string; name: string } }

const DAY = 86_400_000

function secret(): string {
  return process.env.SESSION_SECRET || "st-" + (process.env.ADMIN_CODE || "") + "-" + (process.env.DATABASE_URL || "").slice(-24)
}
export function adminCode(): string {
  return String(process.env.ADMIN_CODE || "").normalize("NFKC").trim()
}
export function normCode(s: unknown): string {
  return String(s ?? "").normalize("NFKC").trim().toUpperCase()
}
function fp(s: string): string {
  return crypto.createHmac("sha256", secret()).update("fp:" + s).digest("hex").slice(0, 10)
}
export function same(a: string, b: string): boolean {
  const x = crypto.createHash("sha256").update(a).digest()
  const y = crypto.createHash("sha256").update(b).digest()
  return crypto.timingSafeEqual(x, y)
}
function sign(p: object): string {
  const body = Buffer.from(JSON.stringify(p)).toString("base64url")
  const sig = crypto.createHmac("sha256", secret()).update(body).digest("base64url")
  return body + "." + sig
}
function verify(tok: string): any | null {
  const i = tok.indexOf(".")
  if (i < 1) return null
  const body = tok.slice(0, i)
  const sig = tok.slice(i + 1)
  const want = crypto.createHmac("sha256", secret()).update(body).digest("base64url")
  if (sig.length !== want.length || !same(sig, want)) return null
  try {
    return JSON.parse(Buffer.from(body, "base64url").toString("utf8"))
  } catch {
    return null
  }
}

/** トークン発行。チーム用はチームコードの指紋(cv)を含め、コード変更で自動的に失効する */
export function mint(k: Kind, tid?: string, code?: string): string {
  const p: any = { k, exp: Date.now() + (k === "A" ? 7 : 30) * DAY }
  if (tid) p.tid = tid
  if (k === "t" || k === "v") p.cv = fp("team:" + code)
  if (k === "a" || k === "A") p.ac = fp("admin:" + adminCode())
  return sign(p)
}

let ready: Promise<void> | null = null
export function ensureSchema(): Promise<void> {
  if (!ready) {
    ready = (async () => {
      await pool.query("CREATE SEQUENCE IF NOT EXISTS st_rev")
      await pool.query(
        "CREATE TABLE IF NOT EXISTS st_docs (col text NOT NULL, id text NOT NULL, j text, deleted boolean NOT NULL DEFAULT false, rev bigint NOT NULL DEFAULT nextval('st_rev'), updated_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY (col, id))",
      )
      await pool.query("CREATE INDEX IF NOT EXISTS st_docs_rev_idx ON st_docs (rev)")
      await pool.query(
        "CREATE TABLE IF NOT EXISTS st_teams (id text PRIMARY KEY, name text NOT NULL, code text NOT NULL, created_at timestamptz NOT NULL DEFAULT now())",
      )
      await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS st_teams_code_idx ON st_teams (code)")
      await pool.query(
        "CREATE TABLE IF NOT EXISTS st_shares (token text PRIMARY KEY, tid text NOT NULL, mid text NOT NULL, revoked boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE (tid, mid))",
      )
    })().catch((e) => {
      ready = null
      throw e
    })
  }
  return ready
}

export async function getSession(req: Request): Promise<Session | null> {
  const h = req.headers.get("authorization") || ""
  const p = verify(h.startsWith("Bearer ") ? h.slice(7) : "")
  if (!p || typeof p.exp !== "number" || p.exp < Date.now()) return null
  const ac = adminCode()
  const adminOk = !!ac && p.ac === fp("admin:" + ac)
  if (p.k === "A") return adminOk ? { k: "A" } : null
  if (p.k !== "t" && p.k !== "v" && p.k !== "a") return null
  if (typeof p.tid !== "string") return null
  await ensureSchema()
  const r = await pool.query("SELECT id, name, code FROM st_teams WHERE id = $1", [p.tid])
  const t = r.rows[0]
  if (!t) return null
  if (p.k === "a") {
    if (!adminOk) return null
  } else if (p.cv !== fp("team:" + t.code)) return null
  return { k: p.k, tid: t.id, team: { id: t.id, name: t.name } }
}

/* ログイン試行の簡易レート制限（同一IPで10分に10回まで失敗可）。サーバーレス環境ではインスタンス単位の目安です */
const fails = new Map<string, { n: number; t: number }>()
export function clientIp(req: Request): string {
  return (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || "local"
}
export function isLimited(ip: string): boolean {
  const f = fails.get(ip)
  if (!f) return false
  if (Date.now() - f.t > 600_000) {
    fails.delete(ip)
    return false
  }
  return f.n >= 10
}
export function addFail(ip: string) {
  const f = fails.get(ip)
  if (!f || Date.now() - f.t > 600_000) fails.set(ip, { n: 1, t: Date.now() })
  else f.n++
}
export function clearFail(ip: string) {
  fails.delete(ip)
}
export const noStore = { "Cache-Control": "no-store" }
