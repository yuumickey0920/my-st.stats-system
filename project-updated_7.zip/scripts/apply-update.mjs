// Usage: node scripts/apply-update.mjs <new-claude-export.html>
// Merges a new ST.stats HTML from Claude with the web app shell (PWA head, cloud sync, auto-update)
// and writes public/index.html. User data lives in the database / localStorage and is untouched.
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const src = process.argv[2]
if (!src) {
  console.error('Usage: node scripts/apply-update.mjs <file.html>')
  process.exit(1)
}

let html = readFileSync(src, 'utf8')
const head = readFileSync(join(root, 'app-shell/head.html'), 'utf8')
const cloud = readFileSync(join(root, 'app-shell/cloud.js'), 'utf8')

const fail = (msg) => {
  console.error('apply-update: ' + msg)
  process.exit(1)
}

if (!html.includes('</head>')) fail('</head> not found')
html = html.replace('</head>', head + '</head>')

const claudeInit = 'if(window.claude&&claude.use)DB=await claude.use("db")'
if (!html.includes(claudeInit)) fail('initSync hook not found; sync code may have changed')
// replace every occurrence (older duplicated initSync definitions may exist; the last one wins at runtime)
html = html.split(claudeInit).join('if(location.protocol.indexOf("http")==0)DB=cloudDB();else ' + claudeInit)

const end = html.lastIndexOf('</script>')
if (end < 0) fail('</script> not found')
html = html.slice(0, end) + cloud + html.slice(end)

writeFileSync(join(root, 'public/index.html'), html)
console.log('public/index.html updated (' + html.length + ' bytes)')
